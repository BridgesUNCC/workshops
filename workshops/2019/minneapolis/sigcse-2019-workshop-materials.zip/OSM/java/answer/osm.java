import java.util.Map;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Comparator;

import bridges.base.Element;
import bridges.base.SLelement;
import bridges.base.GraphAdjList;
import bridges.base.Edge;
import bridges.base.Color;
import bridges.base.ElementVisualizer;
import bridges.base.LinkVisualizer;
import bridges.connect.Bridges;
import bridges.data_src_dependent.OsmData;
import bridges.data_src_dependent.OsmVertex;
import bridges.data_src_dependent.OsmEdge;

//class useful as what get pushed in Dijkstra's priority queue
class Pair<Vtx, Dst> {
    Vtx v;
    Dst d;

    Pair(Vtx ve, Dst di) {
	v=ve;
	d=di;
    }

    Dst getValue() {
	return d;
    }

    Vtx getKey() {
	return v;
    }
}

//Comparator use in Dijkstra priority queue
class PQ_Comparator implements Comparator<Pair<Integer, Double>>{

    // Overriding compare()method of Comparator for descending order
    public int compare(Pair<Integer,Double> p1, Pair<Integer,Double> p2) {
	double d1 = p1.getValue().doubleValue();
	if (p1.getValue().doubleValue() < p2.getValue().doubleValue())
	    return 1;
	else if (p1.getValue().doubleValue() > p2.getValue().doubleValue())
	    return -1;
	return 0;
    }
}




public class osm {

    //returns the relative difference between two double. Useful to
    //compare equality between doubles.
    public static double RelDif(double a, double b)
    {
	double c = Math.abs(a);
	double d = Math.abs(b);

	d = Math.max(c, d);

	return d == 0.0 ? 0.0 : Math.abs(a - b) / d;
    }


    //dijsktra's shortest path algorithm 
    public static void dijkstra (GraphAdjList<Integer, OsmVertex, Double> gr,
			  int source,
			  HashMap<Integer, Double> distance,
			  HashMap<Integer, Integer> parent) {

	for (Map.Entry<Integer, Element<OsmVertex> > pai : gr.getVertices().entrySet())
	    distance.put (pai.getKey(), Double.MAX_VALUE);

	distance.put(source, 0.);

	//using a pair<vertex, distance> in the queue rather than just vertex
	//becasue I am not sure how the heap is going to like the vertices changing silently distance.
	//should really use a fibonacci heap.
  
	PriorityQueue<Pair<Integer, Double>> pq = new PriorityQueue<Pair<Integer, Double>> (100, new PQ_Comparator());
  
	pq.add(new Pair<Integer, Double>(source, distance.get(source)));

	//as long as the queue is not empty
	while (!pq.isEmpty()) {
	    int from = pq.peek().getKey();
	    pq.remove();

	    double d_from = distance.get(from);

	    //iterate over neighbors
	    SLelement<Edge<Integer, Double>> list = gr.getAdjacencyList(from);
	    while (list != null) {
		int  to = list.getValue().getVertex();
		Double ddd = list.getValue().getEdgeData();
		double edgelength = ddd;
      
		double pathlength = d_from + edgelength;
		if (pathlength < distance.get(to)) { //new shortest path found
		    distance.put(to, pathlength);
		    pq.add(new Pair<Integer, Double>(to, pathlength));
		    parent.put(to, from);
		}
      
		list = list.getNext();
	    }
	}  
    }


    // return the vertex from the graph that is the closest to (lat,lon)
    public static int getClosestVertex(GraphAdjList<Integer, OsmVertex, Double> graph, double lat, double lon) {
	int minindex = 0;
	double dist = Double.MAX_VALUE;
	
	for (int i=1; i<graph.getVertices().size(); ++i) {
	    OsmVertex v = graph.getVertex(i).getValue();
	    double d1 = v.getLatitude()-lat;
	    double d2 = v.getLongitude()-lon;
	    double locdist = d1*d1 + d2*d2;
	    if (locdist < dist) {
		minindex = i;
		dist = locdist;
	    }	    
	}
	return minindex;
    }

    //this function is used to style vertices based on their distance to the source
    public static void styleDistance(GraphAdjList<Integer, OsmVertex, Double> graph,
				HashMap<Integer, Double> distance) {
	double maxd=0.;
	
	//find max distance
	for (Map.Entry<Integer, Double> pai : distance.entrySet()) {
	    double d = pai.getValue();

	    if (d < Double.MAX_VALUE) {
		if (d > maxd)
		    maxd = d;
	    }
	}

	//color vertices based on distances
	for (Map.Entry<Integer, Double> pai : distance.entrySet()) {
	    int v = pai.getKey();
	    double d = pai.getValue();

	    ElementVisualizer elvis = graph.getVertex(v).getVisualizer();
	    if (d<Double.MAX_VALUE)
		elvis.setColor(new Color((int) (255*((maxd-d)/maxd)),(int) (255*((maxd-d)/maxd)),(int) (255*((maxd-d)/maxd))));
	}

	//color edges that are shortest path edge
	for (Map.Entry<Integer, Element<OsmVertex>> pai : graph.getVertices().entrySet()) { //for each vertex
	    int  from = pai.getKey();
	    double d_from = distance.get(from);

	    if (d_from == Double.MAX_VALUE)
		continue;


	    SLelement<Edge<Integer, Double>> list = graph.getAdjacencyList(from);
	    while (list != null) { //for each edge
		int to = list.getValue().getVertex();
		double d_to = distance.get(to);

		double edgelength = list.getValue().getEdgeData();
	          
		if (RelDif(d_from + edgelength, d_to)<0.001) {//This is the SP edge
		    try {
			LinkVisualizer livis = graph.getLinkVisualizer(from, to);
			livis.setColor(0, 0, 0, 1.0f);
		    } catch (Exception e) { //can be ignored
		    }
		}
		else if (RelDif(d_to+edgelength, d_from)<0.001) { //this is the reverse edge from an SP edge color it anyway
		    try {
			LinkVisualizer  livis = graph.getLinkVisualizer(from, to);
			livis.setColor(0,0,0,1.0f);
		    } catch (Exception e) {
		    }
		}
		else { //This is not the SP edge
		    try {
			LinkVisualizer livis = graph.getLinkVisualizer(from, to);
			livis.setColor(255,0,0,(float)(50/255.));
		    } catch(Exception e) {
		    }
		}
		list = list.getNext();
	    }
	}
    }

    //style the graph by greying out all vertices and edges except
    //those on the SP between the source and destinatin. (No need to
    //pass the source since all parent chase go there.)
    public static void styleParent(GraphAdjList<Integer, OsmVertex, Double> graph,
			    HashMap<Integer, Double> distance,
			    HashMap<Integer, Integer> parent,
			    int dest
			    ) {
	double maxd=0.;
	
	//set all edges to transparent
	for (Map.Entry<Integer, Element<OsmVertex>>  pai : graph.getVertices().entrySet()) {
	    int from = pai.getKey();

	    SLelement<Edge<Integer, Double>>  list = graph.getAdjacencyList(from);
	    while (list != null) {
		int to = list.getValue().getVertex();

		try {
		    LinkVisualizer livis =  graph.getLinkVisualizer(from, to);
		    livis.setColor(0,0,0,0.2f);
		} catch (Exception e){
		}
      
		list = list.getNext();
	    }
	}

	//set all vertices to transparent
	for (Map.Entry<Integer, Element<OsmVertex>> pai : graph.getVertices().entrySet()) {
	    int from = pai.getKey();

	    ElementVisualizer elvis = pai.getValue().getVisualizer();
	    elvis.setColor(0,0,0,0.2f);
	}

	//for each edge on the SP from source to dest
	int from = dest;
	Integer it = parent.get(from);
	while (it != null) {
	    int prev = it;

	    //color the vertex
	    ElementVisualizer elvis = graph.getVertex(from).getVisualizer();
	    elvis.setColor(0,0,0,1.0f);
    
    
	    //color the edge
	    try {
		LinkVisualizer livis = graph.getLinkVisualizer(prev, from);
		livis.setColor(0,0,0,1.0f);
	    } catch(Exception e) { //can be ignored
	    }

	    //color the reverse edge
	    try {
		LinkVisualizer livis2 = graph.getLinkVisualizer(from, prev);
		livis2.setColor(0,0,0,1.0f);
	    } catch(Exception e) {//can be ignored
	    }
    
	    from = prev;
	    it = parent.get(from);
	}
    }

    //style the root of the shortest path
    public static void styleRoot(GraphAdjList<Integer, OsmVertex, Double> graph,
			  int root) {
	ElementVisualizer elvis = graph.getVertex(root).getVisualizer();
	elvis.setColor(new Color(255,255,255));
    }

    public static void main(String[] args) throws Exception {
  
	//create the Bridges object, set credentials 
	Bridges bridges = new Bridges(Integer.parseInt(args[0]), args[1], args[2]);
	bridges.setTitle("Graph : OpenStreet Map Example");
	bridges.setServer("clone");
  
	//Getting Data
	int closest;
	double latc, lonc;
	int dest;
  
	OsmData osm_data = bridges.getOsmData("uncc_campus");
	GraphAdjList<Integer, OsmVertex, Double> graph = osm_data.getGraph ();

	//OSMData osm_data = ds.getOSMData("shrunk_uncc_campus");
	//OSMData osm_data = ds.getOSMData("uncc_campus");
	//OSMData osm_data = ds.getOSMData("charlotte");

	double[] latr = new double[2];
	double[] lonr = new double[2];
	osm_data.getLatLongRange(latr, lonr);

	
	//Getting source vertex (Using center of the map)
	closest = getClosestVertex(graph,
				   latr[0]+(latr[1]-latr[0])/2.,
				   lonr[0]+(lonr[1]-lonr[0])/2.);
	
	dest = getClosestVertex(graph,
				latr[0]+(latr[1]-latr[0])/4.,
				lonr[0]+(lonr[1]-lonr[0])/4.);

	//Running shortest path

	HashMap<Integer, Double> distance= new HashMap<Integer, Double>();
	HashMap<Integer, Integer> parent = new HashMap<Integer, Integer>();

	dijkstra(graph, closest, distance, parent);

	//Styling

	styleRoot(graph, closest);
	styleDistance(graph, distance);

	bridges.setDataStructure(graph);
	bridges.visualize();
  
	styleParent(graph, distance, parent, dest);

	bridges.visualize();
    }

}

