#include "Bridges.h"
#include "DataSource.h"
#include "GraphAdjList.h"
#include <iostream>
#include <string>
#include <unordered_map>
#include <fstream>
#include <data_src/OSMData.h>
#include <queue>

using namespace std;
using namespace bridges;

//function used to return the relative distance between doubles.
//useful to compare for equality
double RelDif(double a, double b)
{
  double c = std::abs(a);
  double d = std::abs(b);

  d = (std::max)(c, d);

  return d == 0.0 ? 0.0 : std::abs(a - b) / d;
}


//used to get the coordinate of the center of the map
void getQuarter(const OSMData& osm_data, double& lat, double& lon) {
  double latr[2];
  double lonr[2];
  osm_data.getLatLongRange(latr, lonr);

  lat = latr[0]+(latr[1]-latr[0])/4.;
  lon = lonr[0]+(lonr[1]-lonr[0])/4.;
}

//used to get the coordinate of the (.25,.25) of the map
void getCenter(const OSMData& osm_data, double& lat, double& lon) {
  double latr[2];
  double lonr[2];
  osm_data.getLatLongRange(latr, lonr);

  lat = (latr[0]+latr[1])/2.;
  lon = (lonr[0]+lonr[1])/2.;
}

//actual Dijsktra implementation
void dijkstra (const GraphAdjList<int, OSMVertex, double>& gr,
	       int source,
	       std::unordered_map<int, double>& distance,
	       std::unordered_map<int, int>& parent) {

  //set all distances to infinity
  for (auto& pai : *(gr.getVertices()))
    distance[pai.first] = INFINITY;

  distance[source] = 0.;

  //using a pair<vertex, distance> in the queue rather than just vertex
  //becasue I am not sure how the heap is going to like the vertices changing silently distance.
  //should really use a fibonacci heap.
  
  //lambda function comparing the distance pushed into the priority queue.
  auto compar = [=](const std::pair<int,double>& a, const std::pair<int,double>& b) -> bool { return a.second> b.second;};
  
  std::priority_queue<std::pair<int,double>, std::vector<std::pair<int,double> >,  decltype(compar) > pq (compar);
  
  pq.push(std::make_pair(source, distance[source]));
  while (!pq.empty()) { //while the queue is not empty
    //vertex being processed
    auto from = pq.top().first;
    auto d_from = distance[from];
    pq.pop();
    
    auto list = gr.getAdjacencyList(from);
    while (list != nullptr) { //for all neighbors
      auto to = list->getValue().getVertex();
      auto edgelength = list->getValue().getEdgeData();
      
      auto pathlength = d_from + edgelength;
      if (pathlength < distance[to]) { //new path found
	distance[to] = pathlength;
	pq.push(std::make_pair(to, pathlength));
	parent[to] = from;
      }
      
      list = list->getNext();
    }
  }  
}

//return the vertex the closest to a particular (lat,lon)
int getClosestVertex(const GraphAdjList<int, OSMVertex, double>& graph, double lat, double lon) {

  auto distfunction = [=](const OSMVertex& v) -> double {
    return (v.getLatitude()-lat)*(v.getLatitude()-lat) + (v.getLongitude()-lon)*(v.getLongitude()-lon);
  };
  
  int minindex = 0;
  double dist = distfunction(graph.getVertex(minindex)->getValue());

  for (int i=1; i<graph.getVertices()->size(); ++i) {
    double locdist = distfunction(graph.getVertex(i)->getValue());
    if (locdist < dist) {
      minindex = i;
      dist = locdist;
    }	    
  }

  return minindex;
}

//style all vertices based on their distance to the root of the shortest path.
//style edges based on whether they sit on a shortest path or not
void styleDistance(GraphAdjList<int, OSMVertex, double> graph,
		   const std::unordered_map<int, double>& distance) {
  double maxd=0.;
	
  //find max distance
  for (auto& pai : distance) {
    auto d = pai.second;

    if (d < INFINITY) {
      if (d>maxd)
	maxd=d;
    }
  }

  //color vertices based on distances
  for (auto& pai : distance) {
    auto v = pai.first;
    auto d = pai.second;

    auto elvis = graph.getVertex(v)->getVisualizer();
    if (d<INFINITY)
      elvis->setColor(Color(255*((maxd-d)/maxd),255*((maxd-d)/maxd),255*((maxd-d)/maxd)));
  }

  //color edges
  for (auto& pai : *(graph.getVertices())) {
    auto from = pai.first;
    auto d_from = distance.at(from);

    if (d_from == INFINITY)
      continue;
    
    auto list = graph.getAdjacencyList(from);
    while (list != nullptr) {
      auto to = list->getValue().getVertex();
      auto d_to = distance.at(to);

      auto edgelength = list->getValue().getEdgeData();
	    
      if (RelDif(d_from + edgelength, d_to)<0.001) { //This is the SP edge
	auto livis = graph.getLinkVisualizer(from, to);
	livis->setColor(Color(0,0,0,255));
      }
      else if (RelDif(d_to+edgelength, d_from)<0.001) { //this is the reverse edge from an SP edge. color it anyway
	auto livis = graph.getLinkVisualizer(from, to);
	livis->setColor(Color(0,0,0,255));
      }
      else { //This is not the SP edge
	LinkVisualizer* livis = graph.getLinkVisualizer(from, to);
	livis->setColor(Color(255,0,0,50)); //faded edge
      }
	    
      list = list->getNext();
    }
  }
}

//style graph based on whether vertices and edges sit on the shortest path between dest and source. (Note that source is not given since all parent pointer chase go there)
void styleParent(GraphAdjList<int, OSMVertex, double> graph,
		 const std::unordered_map<int, double>& distance,
		 const std::unordered_map<int, int>& parent,
		 int dest
		 ) {
  //set all edges to transparent
  for (auto& pai : *(graph.getVertices())) {//for all vertices
    auto from = pai.first;

    auto list = graph.getAdjacencyList(from);
    while (list != nullptr) {//for all neighbor
      auto to = list->getValue().getVertex();
      
      auto livis =  graph.getLinkVisualizer(from, to);
      livis->setColor(Color(0,0,0,50));
      list = list->getNext();
    }
  }

  //set all vertices to transparent
  for (auto& pai : *(graph.getVertices())) {//for all vertices
    auto from = pai.first;

    auto elvis = pai.second->getVisualizer();
    elvis->setColor(Color(0,0,0,50));
  }

  //for each edge on the SP from source to dest
  int from = dest;
  auto it = parent.find(from);
  while (it != parent.end()) {
    int prev = it->second;

    //color the vertex
    auto elvis = graph.getVertex(from)->getVisualizer();
    elvis->setColor(Color(0,0,0,255));
    
    //color the edge
    auto livis = graph.getLinkVisualizer(prev, from);
    if (livis != nullptr)
      livis->setColor(Color(0,0,0,255));

    auto livis2 = graph.getLinkVisualizer(from, prev);
    if (livis2 != nullptr) //some reverse edge may not exist
      livis2->setColor(Color(0,0,0,255));

    from = prev;
    it = parent.find(from);
  }
}

//change the style of the root of the shortest path
void styleRoot(GraphAdjList<int, OSMVertex, double>& graph,
	       int root) {
  auto elvis = graph.getVertex(root)->getVisualizer();
  // elvis->setShape(DIAMOND);
  // elvis->setSize(49);
  elvis->setColor(Color(255,255,255,255));
}

int main(int argc, char **argv) {
  
  //create the Bridges object, set credentials
  Bridges bridges(std::atoi(argv[1]), argv[2], argv[3]  );
  bridges.setTitle("Graph : OpenStreet Map Example");
  bridges.setServer("clone");
  
  //Getting Data
  int closest;
  double latc, lonc;
  int dest;

  DataSource ds (&bridges);
  OSMData osm_data = ds.getOSMData("uncc_campus");
  GraphAdjList<int, OSMVertex, double> graph;
  osm_data.getGraph (&graph);

  
  //Getting source vertex (Using center of the map)
  getCenter(osm_data, latc, lonc);
  closest = getClosestVertex(graph, latc, lonc);
  //Getting destination vertex
  getQuarter(osm_data, latc, lonc);
  dest = getClosestVertex(graph, latc, lonc);

    
  
  //Running shortest path
  std::unordered_map<int, double> distance;
  std::unordered_map<int, int> parent;
  dijkstra(graph, closest, distance, parent);

  //Styling based on distance
  styleRoot(graph, closest);
  styleDistance(graph, distance);

  bridges.setDataStructure(&graph);
  bridges.visualize();

  //styling based on source-destination path
  styleParent(graph, distance, parent, dest);
  bridges.visualize();

  return 0;
}
